#pragma once

#include "quantum.h"

#ifdef KEYBOARD_ajisai74_rev1
  #include "rev1.h"
#endif
